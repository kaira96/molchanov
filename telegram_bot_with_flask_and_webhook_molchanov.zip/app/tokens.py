cmc_token = 'your_api_token'
