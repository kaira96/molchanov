from kivy.app import App
from kivy.uix.gridlayout import GridLayout
from kivy.properties import ObjectProperty
# from kivy.core.window import Window

from kivymd.theming import ThemeManager

from kivy.config import Config
Config.set('kivy', 'keyboard_mode', 'systemanddock')

# Window.size = (720, 1200)


def get_salting_time(m):
    # 2 days for every 500 g
    return round(m / 500 * 2)


def get_ingridients(m):
    nitro = str(10 * m / 1000)
    salt = str(15 * m / 1000)
    start_culture = str(0.5 * m / 1000)
    dextrose = str(5 * m / 1000)

    salting_time = str(get_salting_time(m))

    return {'nitro': nitro, 'salt': salt, 'start cultures': start_culture, 'dextrose': dextrose, 'salting_time': salting_time}


class Container(GridLayout):
    meat_mass = ObjectProperty()
    salt_result_label = ObjectProperty()
    nitro_salt_result_label = ObjectProperty()
    monosugars_result_label = ObjectProperty()
    startcultures_result_label = ObjectProperty()
    salting_time_label = ObjectProperty()

    def calculate(self):
        try:
            mass = int(self.meat_mass.text)
        except:
            mass = 0

        if mass:
            ingridients = get_ingridients(mass)

            self.salt_result_label.text = ingridients.get('salt') + ' + 5'
            self.nitro_salt_result_label.text = ingridients.get('nitro')
            self.monosugars_result_label.text = ingridients.get('dextrose')
            self.startcultures_result_label.text = ingridients.get('start cultures')
            self.salting_time_label.text = ingridients.get('salting_time')
        else:
            self.salt_result_label.text = ''
            self.nitro_salt_result_label.text = ''
            self.monosugars_result_label.text = ''
            self.startcultures_result_label.text = ''
            self.salting_time_label.text = ''


class MyApp(App):
    theme_cls = ThemeManager()
    title = "Coppa Ingridients Calculator"

    def build(self):
        self.theme_cls.theme_style = 'Light'
        return Container()



if __name__ == '__main__':
    MyApp().run()
